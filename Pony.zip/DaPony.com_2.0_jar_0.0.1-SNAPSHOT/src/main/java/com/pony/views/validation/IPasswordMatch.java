package com.pony.views.validation;

public interface IPasswordMatch {
    public String getPassword();
    public String getConfirmPassword();
}