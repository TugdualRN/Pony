package com.pony.enumerations;

public enum SocialNetworkType {
    UNKNOWN,
    FACEBOOK,
    TWITTER,
    INSTAGRAM,
    GOOGLE_PLUS,
    LINKEDIN,
    MYSPACE,
    GITHUB
}