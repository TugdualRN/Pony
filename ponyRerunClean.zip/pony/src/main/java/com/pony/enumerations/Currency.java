package com.pony.enumerations;

public enum Currency {
    EUR, 
    USD
}