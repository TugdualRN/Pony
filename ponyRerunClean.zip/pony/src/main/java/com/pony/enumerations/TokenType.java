package com.pony.enumerations;

public enum TokenType {
    UNKNOWN,
    ACTIVATE_ACCOUNT,
    RESET_PASSWORD,
    CHANGE_MAIL
}